# Smart_Mathematics_tutor

Smart Maths tutor system is a web based graphical user interface where a user gets to draw shapes of mathematical figures such as square, triangle, circle etc. for which the output would be related formulas to the drawn figure.

Libraries Used Tensorflow Keras FLask Numpy Matplotlib
